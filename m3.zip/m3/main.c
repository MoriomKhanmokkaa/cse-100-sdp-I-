
/**---------------------------------------------------------------
Project Tittle : Inventory management System
Project Description :

    It is a very simple management system for "Food Distributions For Flood Victims" that have these
functionality,
    (i)     Adding product
    (ii)    Distributing product
    (iii)   Displaying distributed product
    (iv)    Displaying remaining product
    (v)     Exiting Program

                                 Group-5

Group Member :
                Name                    ID
    (i)   Toma Akter Nighat      (ID:22234103240)
    (ii)  Silvia Salim Labonno   (ID:22234103377)
    (iii) Sharmin Akter Shaheba  (ID:22234103225)
    (iv)  Jannatin Tabassum Saba (ID:22234103238)
    (v)   Moriom Khan Mokka      (ID:22234103145)

**---------------------------------------------------------------**/

/*----------------------------------------------------------------
                        Header Files
**---------------------------------------------------------------*/
#include <stdio.h> // Basic C
#include <windows.h> // Using for CMD command. here system("cls")
#include <conio.h> // Using for getch
/*---------------------------------------------------------------*/

//Product structure
struct prod{
    int id,cnt; // id = id of the product, cnt= count of product
    char name[100]; // product name
    double amount_bag; // amount of the product
} product;


//Products
struct distribution{
    char flood_victim[100]; //Flood victim's name
    char d_prod_name[100]; // Product which will distribute in flood victims
    int d_prod_cnt; // count of the product which will distribute in flood victims
    time_t date; // Distributing date
    double amount_bag; // Amount of bag
}distribution;

//Add New Products

    //Adding Products to the main list
    void add_Products(FILE *f){

        char add_again = 'y';

        while(add_again == 'y' || add_again == 'Y'){ //goes to loop while user enter y;

            system("cls"); // clear console screen
            printf("-------------------------------------------------------------------------------------------------------------------\n");
            printf("\tAdd Products\n");
            printf("-------------------------------------------------------------------------------------------------------------------\n\n");

            //Display Products
            rewind(f);
            int has_Product = 0;
            printf("-------------------------------------------------------------------------------------------------------------------\n");
            printf("\tID\tProduct name\tPerson number\tAmount of bag\tTotal amount of bag\n");
            printf("-------------------------------------------------------------------------------------------------------------------\n");
            while(fread(&product, sizeof(product), 1, f)==1){
                has_Product = 1;
                printf("\t%d",product.id);
                printf("\t\t%s",product.name);
                printf("\t%d\t",product.cnt);
                printf("\t%0.2lf\t",product.amount_bag);
                printf("\t%0.2lf\n",(product.amount_bag*product.cnt));
            }
            if(has_Product){
            printf("--------------------------------------------------------------------------------------------------------------------\n\n");
            }
            else{
                printf("\tNo Entry!\n");
            printf("--------------------------------------------------------------------------------------------------------------------\n\n");
            }

            //Search by Product id
            printf("ID of the product you want to add : ");
            int pid,add_isFound = 0; scanf("%d",&pid);

            //Search Product Availability
            rewind(f);
            FILE *f2;
            f2 = fopen("temp.log","a+");
            while(fread(&product, sizeof(product), 1, f)==1){
                if(pid==product.id){
                    add_isFound = 1;

                    system("cls");

                    printf("----------------------------------------------------------------------------------------------------\n");
                    printf("\tAdd Products\n");
                    printf("----------------------------------------------------------------------------------------------------\n\n");

                    printf("----------------------------------------------------------------------------------------------------\n");
                    printf("\tID\tProduct name\tPerson number\tAmount of bag\tTotal amount of bag\n");
                    printf("----------------------------------------------------------------------------------------------------\n");
                    printf("\t%d",product.id);
                    printf("\t\t%s",product.name);
                    printf("\t%d\t",product.cnt);
                    printf("\t%0.2lf\t",product.amount_bag);
                    printf("\t%0.2lf\n",(product.amount_bag*product.cnt));
                    printf("----------------------------------------------------------------------------------------------------\n\n");

                    printf("Enter the following information....\n");

                    int pro_count = -1;
                    while(pro_count <= 0){
                        printf("Number of aditional person to add: ");
                        scanf("%d",&pro_count);
                        if(pro_count <= 0){
                            printf("Number of aditional person should be a positive number!\n\nRewrite the number");
                        }
                    }

                    product.cnt += pro_count;
                    product.amount_bag = -1.00;

                    while(product.amount_bag<=0){
                        printf("New amount of bag of the product : ");
                        scanf("%lf",&product.amount_bag);
                        if(product.amount_bag<=0){
                            printf("Amount of bag should be greater than zero!\n\nRewrite the number");
                        }
                    }

                    fwrite(&product,sizeof(product),1,f2);
                }

                else{
                    fwrite(&product,sizeof(product),1,f2);
                }
            }

            fclose(f2); //Closing temp.log File
            fclose(f);  //Closing file.log File
            remove("file.log");
            rename("temp.log","file.log");
            f = fopen("file.log","a+");

            if(add_isFound == 0){
                printf("\nThis Item is not Listed in the List.\nDo You want to add? (Y/N) : ");

                char list_product;
                scanf("%s",&list_product);
                if(list_product == 'Y' ||list_product == 'y'){
                    product.id = pid;
                    printf("\nID of the product : %d\n",product.id);
                    fflush(stdin);
                    printf("Name of the product : ");
                    scanf("%[^\n]s",product.name);
                    product.cnt = -1;
                    while(product.cnt <= 0){
                        printf("Number of person : ");
                        scanf("%d",&product.cnt);
                        if(product.cnt <= 0){
                            printf("Number of person should be a positive number ! \n\nRewrite the number");
                        }
                    }
                    product.amount_bag = -1.00;
                    while(product.amount_bag <= 0.00){
                        printf("Amount of bag : ");
                        scanf("%lf",&product.amount_bag);
                        if(product.amount_bag<= 0.00){
                            printf("Amount of bag should be greater than zero!\n\nRewrite the number");
                        }
                    }
                    fwrite(&product,sizeof(product),1,f);
                }
            }

            // Add Again?
            printf("Do you want to add more ? (Y/N) : ");
            scanf("%c",&add_again);
        }
    }


//View Remaining Products

    void V_R_P(FILE *f){
        rewind(f);
        int has_Product = 0;
        system("cls");
        printf("------------------------------------------------------------------------------------------------------------\n");
        printf("Remaining Products\n");
        printf("------------------------------------------------------------------------------------------------------------\n\n");
        printf("------------------------------------------------------------------------------------------------------------\n");
        printf("\tID\tProduct name\tPerson number\tAmount of bag\tTotal amount of bag\n");
        printf("------------------------------------------------------------------------------------------------------------\n");

        double g_total = 0;
        while(fread(&product, sizeof(product), 1, f)==1){
            has_Product = 1;
            printf("\t%d",product.id);
            printf("\t\t%s",product.name);
            printf("\t%d\t",product.cnt);
            printf("\t%0.2lf\t",product.amount_bag);
            printf("\t%0.2lf\n",(product.amount_bag*product.cnt));
            g_total += product.amount_bag*product.cnt;
        }
        if(has_Product){
        printf("-------------------------------------------------------------------------------------------------------------\n");
        printf("\tGrand Total = %0.2lf\n\n",g_total);
        }
        else{
            printf("\tNo Entry!\n");
        printf("-------------------------------------------------------------------------------------------------------------\n\n");
        }
        printf("Enter Any Key to return main menu....");
        getch();
    }


//View Distributed Products

    void V_D_P(FILE*f){
        FILE *view_d_p;
        view_d_p = fopen("Distributed.log","r");
        int has_Product = 0;
        system("cls");
        printf("---------------------------------------------------------------------------------------------------------------------\n");
        printf("View Distributed Products\n");
        printf("---------------------------------------------------------------------------------------------------------------------\n\n");
        printf("---------------------------------------------------------------------------------------------------------------------\n");
        printf("\tOfficer\t\t\tProduct Name\tPerson number\tAmount of bag\tTotal amount of bag\n");
        printf("---------------------------------------------------------------------------------------------------------------------\n");

        double g_total = 0;
        while(fread(&distribution, sizeof(distribution), 1, view_d_p)==1){
            has_Product = 1;
            int first_line =35;
            printf("\t%s\t",distribution.flood_victim);
            printf("\t%s\t",distribution.d_prod_name);
            printf("\t%d\t",distribution.d_prod_cnt);
            printf("\t%0.2lf\t",distribution.amount_bag);
            printf("\t%0.2lf\n",distribution.d_prod_cnt*distribution.amount_bag);

            g_total += distribution.d_prod_cnt*distribution.amount_bag;
        }
        if(has_Product){
            printf("---------------------------------------------------------------------------------------------------------------------\n");
            printf("\tGrand Total = %0.2lf\n\n",g_total);
        }
        else{
            printf("No Entry!\n");
        }
        fclose(view_d_p);
        printf("Enter Any Key to return main menu....");
        getch();
    }




    void D_P(FILE *f){
        rewind(f);
        int has_Product = 0;
        system("cls");
        printf("---------------------------------------------------------------------------------------------------------\n");
        printf("Distribute product\n");
        printf("---------------------------------------------------------------------------------------------------------\n\n");
        printf("---------------------------------------------------------------------------------------------------------\n");
        printf("\tID\tProduct name\tPerson number\tAmount of bag\tTotal amount of bag\n");
        printf("---------------------------------------------------------------------------------------------------------\n");
        while(fread(&product, sizeof(product), 1, f)==1){
            has_Product = 1;
            printf("\t%d",product.id);
            printf("\t\t%s",product.name);
            printf("\t%d\t",product.cnt);
            printf("\t%0.2lf\t",product.amount_bag);
            printf("\t%0.2lf\n",(product.amount_bag*product.cnt));
        }
        if(has_Product == 0){
            printf("No Entry!\n");
            printf("Enter Any Key to return main menu....");
            getch();
        }
        else{
            printf("---------------------------------------------------------------------------------------------------------\n\n");

            char people[100] = "Default";
            char distribute_more = 'Y',same_people = 'N';
            while(distribute_more == 'Y' || distribute_more == 'y'){
                if(people == "Default" || (same_people != 'Y' && same_people != 'y')){
                    printf("Distributor officer's name : ");
                    fflush(stdin);
                    scanf("%[^\n]s",&people);
                }

                strcpy(distribution.flood_victim,people);
                int p_found = 0;
                while(p_found == 0){

                    int p_id;
                    printf("Product ID : ");
                    scanf("%d",&p_id);

                    FILE *TP;
                    TP = fopen("temporary.log","a");

                    rewind(f);
                    while(fread(&product, sizeof(product), 1, f)==1){
                        if(p_id == product.id){
                            strcpy(distribution.d_prod_name,product.name);
                            printf("Product name : %s\n",distribution.d_prod_name);

                            int p_count = 0,pc;
                            while(p_count == 0){
                                printf("For distribute %s enter number of person:",distribution.d_prod_name);
                                scanf("%d",&pc);
                                if(pc < 1 || pc > product.cnt){
                                    printf("You cannot distribute %d %s\n",pc,distribution.d_prod_name);
                                    printf("Re Enter the number");
                                }
                                else{
                                    p_count = 1;
                                }
                            }
                            distribution.d_prod_cnt = pc;
                            product.cnt -= pc;
                            distribution.amount_bag = product.amount_bag;
                            printf("Amount of bag: %0.2lf\n",distribution.amount_bag*distribution.d_prod_cnt);
                           distribution.date = time(0);
                            p_found = 1;
                        }
                        fwrite(&product, sizeof(product), 1, TP);
                    }

                    fclose(TP);
                    fclose(f);
                    remove("file.log");
                    rename("temporary.log","file.log");
                    f = fopen("file.log","a+");

                    if(p_found == 0) printf("Wrong ID!\nRewrite ");
                    else{
                        FILE *SP;
                        SP = fopen("Distributed.log","a+");
                        fwrite(&distribution, sizeof(distribution), 1, SP);
                        fclose(SP);
                    }
                }
                printf("Do You want to distribute more? (Y/N) : ");
                scanf("%s",&distribute_more);
                if(distribute_more == 'Y' || distribute_more == 'y'){
                    printf("Is it the same distributor? (Y/N) : ");
                    scanf("%c",&same_people);
                }
            }
        }
    }


    mainMenu(FILE *f){
        while(1){
            system("cls");
            //Main Menu
            printf("------------------------------------------------------------\n");
            printf("\tFood Distributions For Flood Victims\n");
            printf("------------------------------------------------------------\n");
            printf("[1] ---------- Add Products\n");
            printf("[2] ---------- Distribute Products\n");
            printf("[3] ---------- View Distributed Products\n");
            printf("[4] ---------- View Remaining Products\n");
            printf("[0] ---------- Exit Program\n");
            printf("------------------------------------------------------------\n\n");

            //Choosing from main menu;
            printf("Enter Your Choice : ");
            int main_Menu_opt;
            scanf("%d",&main_Menu_opt);

            //switch using main menu options
            switch(main_Menu_opt){
                case 1:{
                    add_Products(f);
                    break;
                }
                case 2:{
                    D_P(f);
                    break;
                }
                case 3:{
                    V_D_P(f);
                    break;
                }
                case 4:{
                    V_R_P(f);
                    break;
                }
                case 0:{system("cls");
                    printf("\n\n\n---------------------------*END*----------------------------\n\n");
                    exit(1);
                }
                default:{
                    printf("Wrong Option Selected!\nDouble Press Any Key to continue to Main Menu...");
                    getch();
                }
            }
        }
    }

int main(){


    FILE *f;
    f = fopen("file.log","a+");
    mainMenu(f);
    fclose(f);
}









